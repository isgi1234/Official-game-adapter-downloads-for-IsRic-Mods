using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;

public class IsRicModsAdapter : Mod
{
    private readonly Dictionary<string, string> settings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, string> handledActions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    private string settingsPath;
    private DateTime lastWrite;
    private float nextRead;
    private Vector3 originalGravity;
    private float originalTimeScale;
    private float originalFixedDelta;
    private float originalVolume;
    private int originalTargetFps;
    private int originalVSync;
    private bool originalFog;
    private float originalFogDensity;
    private float originalShadowDistance;
    private float originalLodBias;
    private int originalSolverIterations;
    private float originalSleepThreshold;

    public void Start()
    {
        settingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "IsRic Mods", "Adapters", "raft", "settings.cfg");
        originalGravity = Physics.gravity;
        originalTimeScale = Time.timeScale;
        originalFixedDelta = Time.fixedDeltaTime;
        originalVolume = AudioListener.volume;
        originalTargetFps = Application.targetFrameRate;
        originalVSync = QualitySettings.vSyncCount;
        originalFog = RenderSettings.fog;
        originalFogDensity = RenderSettings.fogDensity;
        originalShadowDistance = QualitySettings.shadowDistance;
        originalLodBias = QualitySettings.lodBias;
        originalSolverIterations = Physics.defaultSolverIterations;
        originalSleepThreshold = Physics.sleepThreshold;
        ReadSettings();
    }

    public void Update()
    {
        if (Time.realtimeSinceStartup >= nextRead)
        {
            nextRead = Time.realtimeSinceStartup + 0.25f;
            ReadSettings();
        }
        float scale = Number("timeScale", 1f, 0.1f, 10f);
        Time.timeScale = scale;
        Time.fixedDeltaTime = originalFixedDelta * scale;
        Physics.gravity = originalGravity * Number("gravity", 1f, 0f, 10f);
        AudioListener.volume = Number("audioVolume", 1f, 0f, 2f);
        Application.targetFrameRate = (int)Number("targetFps", originalTargetFps <= 0 ? 144 : originalTargetFps, 30f, 360f);
        QualitySettings.vSyncCount = Toggle("vSync", originalVSync > 0) ? 1 : 0;
        RenderSettings.fog = Toggle("fog", originalFog);
        RenderSettings.fogDensity = Number("fogDensity", originalFogDensity, 0f, 0.2f);
        QualitySettings.shadowDistance = Number("shadowDistance", originalShadowDistance, 0f, 500f);
        QualitySettings.lodBias = Number("lodBias", originalLodBias, 0.1f, 5f);
        Physics.defaultSolverIterations = (int)Number("solverIterations", originalSolverIterations, 1f, 30f);
        Physics.sleepThreshold = Number("sleepThreshold", originalSleepThreshold, 0f, 1f);
        if (ConsumeAction("givePotatoes")) Give("Raw_Potato", 10);
        if (ConsumeAction("givePlanks")) Give("Plank", 10);
        if (ConsumeAction("givePlastic")) Give("Plastic", 10);
        if (ConsumeAction("giveStone")) Give("Stone", 10);
        if (ConsumeAction("giveScrap")) Give("Scrap", 10);
        if (ConsumeAction("giveRope")) Give("Rope", 10);
    }

    public override void UnloadMod()
    {
        Physics.gravity = originalGravity;
        Time.timeScale = originalTimeScale;
        Time.fixedDeltaTime = originalFixedDelta;
        AudioListener.volume = originalVolume;
        Application.targetFrameRate = originalTargetFps;
        QualitySettings.vSyncCount = originalVSync;
        RenderSettings.fog = originalFog;
        RenderSettings.fogDensity = originalFogDensity;
        QualitySettings.shadowDistance = originalShadowDistance;
        QualitySettings.lodBias = originalLodBias;
        Physics.defaultSolverIterations = originalSolverIterations;
        Physics.sleepThreshold = originalSleepThreshold;
        Destroy(gameObject);
    }

    private void ReadSettings()
    {
        try
        {
            if (!File.Exists(settingsPath)) return;
            DateTime write = File.GetLastWriteTimeUtc(settingsPath);
            if (write == lastWrite) return;
            settings.Clear();
            foreach (string line in File.ReadAllLines(settingsPath))
            {
                int split = line.IndexOf('=');
                if (split > 0) settings[line.Substring(0, split).Trim()] = line.Substring(split + 1).Trim();
            }
            lastWrite = write;
        }
        catch { }
    }

    private float Number(string key, float fallback, float minimum, float maximum)
    {
        string text; float value;
        if (!settings.TryGetValue(key, out text) || !Single.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value)) value = fallback;
        return Mathf.Clamp(value, minimum, maximum);
    }

    private bool Toggle(string key, bool fallback)
    {
        string value;
        if (!settings.TryGetValue(key, out value)) return fallback;
        return value == "1" || value.Equals("true", StringComparison.OrdinalIgnoreCase) || value.Equals("on", StringComparison.OrdinalIgnoreCase);
    }

    private bool ConsumeAction(string key)
    {
        string value;
        if (!settings.TryGetValue(key, out value) || String.IsNullOrWhiteSpace(value) || value == "0") return false;
        string handled;
        if (handledActions.TryGetValue(key, out handled) && handled == value) return false;
        handledActions[key] = value;
        return true;
    }

    private void Give(string itemName, int amount)
    {
        try
        {
            Network_Player player = RAPI.GetLocalPlayer();
            if (player != null) player.Inventory.AddItem(itemName, amount);
        }
        catch (Exception ex) { Debug.LogWarning("IsRic could not give " + itemName + ": " + ex.Message); }
    }
}
