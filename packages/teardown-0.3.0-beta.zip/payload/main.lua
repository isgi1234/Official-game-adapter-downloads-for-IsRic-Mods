#include "settings.lua"

local baseGravity = nil
local baseWalkSpeed = 1
local baseCrouchScale = 1
local baseHurtScale = 1
local handledActions = {}

function init()
    baseGravity = GetGravity()
    baseWalkSpeed = GetPlayerWalkingSpeed(0)
    baseCrouchScale = GetPlayerCrouchSpeedScale(0)
    baseHurtScale = GetPlayerHurtSpeedScale(0)
end

local function setting(name, fallback)
    if IsRic ~= nil and IsRic[name] ~= nil then return IsRic[name] end
    return fallback
end


local function consumeAction(name)
    local token = setting(name, 0)
    if token == 0 or token == handledActions[name] then return false end
    handledActions[name] = token
    return true
end

function tick(dt)
    SetTimeScale(setting("timeScale", 1))
    SetGravity(VecScale(baseGravity, setting("gravity", 1)))
    SetPlayerWalkingSpeed(baseWalkSpeed * setting("walkingSpeed", 1), 0)
    SetPlayerCrouchSpeedScale(baseCrouchScale * setting("crouchSpeed", 1), 0)
    SetPlayerHurtSpeedScale(baseHurtScale * setting("hurtSpeed", 1), 0)
    SetCameraFov(setting("cameraFov", 90))

    if setting("invincible", false) then SetPlayerHealth(1, 0) end
    local regeneration = setting("healthRegeneration", 0)
    if regeneration > 0 then SetPlayerHealth(math.min(1, GetPlayerHealth(0) + regeneration * dt), 0) end

    local tool = GetPlayerTool(0)
    if tool ~= "" then
        SetToolAllowedZoom(setting("toolZoom", true) and 1 or 0, setting("zoomSensitivity", 1))
        if setting("infiniteAmmo", false) then SetToolAmmo(tool, math.floor(setting("toolAmmo", 999)), 0) end
    end

    local vehicle = GetPlayerVehicle(0)
    if vehicle ~= 0 and setting("invincibleVehicle", false) then SetVehicleHealth(vehicle, 1) end

    if consumeAction("healPlayer") then SetPlayerHealth(1, 0) end
    if consumeAction("repairVehicle") and vehicle ~= 0 then SetVehicleHealth(vehicle, 1) end
    if consumeAction("spawnTool") then
        local camera = GetCameraTransform()
        local spawnTransform = TransformToParentTransform(camera, Transform(Vec(0, 0, -2)))
        SpawnTool(setting("toolName", "sledge"), spawnTransform, false, 1)
    end

    if InputPressed("jump") then
        local velocity = GetPlayerVelocity(0)
        velocity[2] = velocity[2] * setting("jumpMultiplier", 1)
        SetPlayerVelocity(velocity, 0)
    end
end
