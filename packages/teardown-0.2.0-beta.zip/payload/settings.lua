-- Default values. IsRic Mods rewrites this file when a launcher control changes.
IsRic = {
    timeScale = 1,
    gravity = 1,
    walkingSpeed = 1,
    crouchSpeed = 1,
    hurtSpeed = 1,
    cameraFov = 90,
    invincible = false,
    healthRegeneration = 0,
    infiniteAmmo = false,
    toolAmmo = 999,
    invincibleVehicle = false,
    jumpMultiplier = 1,
    toolZoom = true,
    zoomSensitivity = 1,
}
