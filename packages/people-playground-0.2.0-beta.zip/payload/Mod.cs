using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using UnityEngine;

namespace Mod
{
    public static class Mod
    {
        private static readonly Dictionary<string, string> Settings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        private static string settingsPath;
        private static DateTime lastWrite;
        private static float nextRead;
        private static bool captured;
        private static Vector2 originalGravity;
        private static float originalTimeScale;
        private static float originalFixedDelta;
        private static float originalVolume;
        private static int originalTargetFps;
        private static int originalVSync;
        private static int originalVelocityIterations;
        private static int originalPositionIterations;
        private static float originalShadowDistance;
        private static float originalLodBias;
        private static bool originalFog;
        private static float originalFogDensity;
        private static readonly Dictionary<string, string> HandledActions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        private static GameObject controllerObject;

        public static void OnLoad()
        {
            settingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "IsRic Mods", "Adapters", "people-playground", "settings.cfg");
            CaptureOriginals();
            ReadSettings();
            if (controllerObject == null)
            {
                controllerObject = new GameObject("IsRic Mods controller");
                UnityEngine.Object.DontDestroyOnLoad(controllerObject);
                controllerObject.AddComponent<IsRicController>();
            }
        }

        public static void Main()
        {
            if (!captured) OnLoad();
            Tick();
        }

        public static void Tick()
        {
            if (Time.realtimeSinceStartup >= nextRead) { nextRead = Time.realtimeSinceStartup + 0.25f; ReadSettings(); }
            float timeScale = Number("timeScale", 1f, 0.1f, 10f);
            Time.timeScale = timeScale;
            Time.fixedDeltaTime = originalFixedDelta * Number("fixedTimestep", 1f, 0.1f, 4f);
            Physics2D.gravity = originalGravity * Number("gravity", 1f, 0f, 10f);
            AudioListener.volume = Number("audioVolume", 1f, 0f, 2f);
            Application.targetFrameRate = (int)Number("targetFps", 144f, 30f, 360f);
            QualitySettings.vSyncCount = Toggle("vSync", originalVSync > 0) ? 1 : 0;
            Physics2D.velocityIterations = (int)Number("velocityIterations", originalVelocityIterations, 1f, 30f);
            Physics2D.positionIterations = (int)Number("positionIterations", originalPositionIterations, 1f, 30f);
            QualitySettings.shadowDistance = Number("shadowDistance", originalShadowDistance, 0f, 500f);
            QualitySettings.lodBias = Number("lodBias", originalLodBias, 0.1f, 5f);
            RenderSettings.fog = Toggle("fog", originalFog);
            RenderSettings.fogDensity = Number("fogDensity", originalFogDensity, 0f, 0.2f);
            if (ConsumeAction("spawnHuman")) Spawn("Human");
            if (ConsumeAction("spawnAndroid")) Spawn("Android");
            if (ConsumeAction("spawnGorse")) Spawn("Gorse");
            if (ConsumeAction("spawnBrick")) Spawn("Brick");
            if (ConsumeAction("spawnPistol")) Spawn("Pistol");
            if (ConsumeAction("spawnSword")) Spawn("Sword");
            if (ConsumeAction("spawnCrate")) Spawn("Crate");
        }

        public static void OnUnload()
        {
            if (!captured) return;
            Physics2D.gravity = originalGravity;
            Time.timeScale = originalTimeScale;
            Time.fixedDeltaTime = originalFixedDelta;
            AudioListener.volume = originalVolume;
            Application.targetFrameRate = originalTargetFps;
            QualitySettings.vSyncCount = originalVSync;
            Physics2D.velocityIterations = originalVelocityIterations;
            Physics2D.positionIterations = originalPositionIterations;
            QualitySettings.shadowDistance = originalShadowDistance;
            QualitySettings.lodBias = originalLodBias;
            RenderSettings.fog = originalFog;
            RenderSettings.fogDensity = originalFogDensity;
            if (controllerObject != null) UnityEngine.Object.Destroy(controllerObject);
        }

        private static void Spawn(string name)
        {
            try
            {
                SpawnableAsset asset = ModAPI.FindSpawnable(name);
                if (asset != null && CatalogBehaviour.Main != null)
                {
                    MethodInfo spawn = typeof(CatalogBehaviour).GetMethod("Spawn", BindingFlags.Instance | BindingFlags.NonPublic, null, new Type[] { typeof(SpawnableAsset), typeof(bool) }, null);
                    if (spawn != null) spawn.Invoke(CatalogBehaviour.Main, new object[] { asset, false });
                }
            }
            catch (Exception ex) { ModAPI.Notify("IsRic could not spawn " + name + ": " + ex.Message); }
        }

        private static bool ConsumeAction(string key)
        {
            string value;
            if (!Settings.TryGetValue(key, out value) || String.IsNullOrWhiteSpace(value) || value == "0") return false;
            string handled;
            if (HandledActions.TryGetValue(key, out handled) && handled == value) return false;
            HandledActions[key] = value;
            return true;
        }

        private static void CaptureOriginals()
        {
            if (captured) return;
            captured = true;
            originalGravity = Physics2D.gravity;
            originalTimeScale = Time.timeScale;
            originalFixedDelta = Time.fixedDeltaTime;
            originalVolume = AudioListener.volume;
            originalTargetFps = Application.targetFrameRate;
            originalVSync = QualitySettings.vSyncCount;
            originalVelocityIterations = Physics2D.velocityIterations;
            originalPositionIterations = Physics2D.positionIterations;
            originalShadowDistance = QualitySettings.shadowDistance;
            originalLodBias = QualitySettings.lodBias;
            originalFog = RenderSettings.fog;
            originalFogDensity = RenderSettings.fogDensity;
        }

        private static void ReadSettings()
        {
            try
            {
                if (!File.Exists(settingsPath)) return;
                DateTime write = File.GetLastWriteTimeUtc(settingsPath);
                if (write == lastWrite) return;
                Settings.Clear();
                foreach (string line in File.ReadAllLines(settingsPath))
                {
                    int split = line.IndexOf('=');
                    if (split > 0) Settings[line.Substring(0, split).Trim()] = line.Substring(split + 1).Trim();
                }
                lastWrite = write;
            }
            catch { }
        }

        private static float Number(string key, float fallback, float minimum, float maximum)
        {
            string text;
            float value;
            if (!Settings.TryGetValue(key, out text) || !Single.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value)) value = fallback;
            return Mathf.Clamp(value, minimum, maximum);
        }

        private static bool Toggle(string key, bool fallback)
        {
            string value;
            if (!Settings.TryGetValue(key, out value)) return fallback;
            return value == "1" || value.Equals("true", StringComparison.OrdinalIgnoreCase) || value.Equals("on", StringComparison.OrdinalIgnoreCase);
        }

        private sealed class IsRicController : MonoBehaviour
        {
            private void Update() { Mod.Tick(); }
        }
    }
}
