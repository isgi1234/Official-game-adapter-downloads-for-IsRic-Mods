using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using UnityEngine;
using UnityEngine.AI;

public class IsRicModsAdapter : Mod
{
    private readonly Dictionary<string, string> settings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, string> handledActions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    private string settingsPath;
    private DateTime lastWrite;
    private float nextRead;
    private Vector3 originalGravity;
    private float originalTimeScale;
    private float originalFixedDelta;
    private float originalVolume;
    private int originalTargetFps;
    private int originalVSync;
    private bool originalFog;
    private float originalFogDensity;
    private float originalShadowDistance;
    private float originalLodBias;
    private int originalSolverIterations;
    private float originalSleepThreshold;

    public void Start()
    {
        settingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "IsRic Mods", "Adapters", "raft", "settings.cfg");
        originalGravity = Physics.gravity;
        originalTimeScale = Time.timeScale;
        originalFixedDelta = Time.fixedDeltaTime;
        originalVolume = AudioListener.volume;
        originalTargetFps = Application.targetFrameRate;
        originalVSync = QualitySettings.vSyncCount;
        originalFog = RenderSettings.fog;
        originalFogDensity = RenderSettings.fogDensity;
        originalShadowDistance = QualitySettings.shadowDistance;
        originalLodBias = QualitySettings.lodBias;
        originalSolverIterations = Physics.defaultSolverIterations;
        originalSleepThreshold = Physics.sleepThreshold;
        ReadSettings();
    }

    public void Update()
    {
        if (Time.realtimeSinceStartup >= nextRead)
        {
            nextRead = Time.realtimeSinceStartup + 0.25f;
            ReadSettings();
        }
        Network_Player player = RAPI.GetLocalPlayer();
        if (player != null)
        {
            if (Toggle("infiniteHealth", false)) Refill(player, new[] { "maxHealth", "MaxHealth" }, new[] { "health", "currentHealth", "Health" });
            if (Toggle("infiniteHunger", false)) Refill(player, new[] { "maxHunger", "MaxHunger" }, new[] { "hunger", "currentHunger", "Hunger" });
            if (Toggle("infiniteThirst", false)) Refill(player, new[] { "maxThirst", "MaxThirst" }, new[] { "thirst", "currentThirst", "Thirst" });
            if (Toggle("infiniteOxygen", false)) Refill(player, new[] { "maxOxygen", "MaxOxygen" }, new[] { "oxygen", "currentOxygen", "Oxygen" });
        }
        if (ConsumeAction("giveItem")) Give(Text("itemName", "Plank"), (int)Number("spawnAmount", 10f, 1f, 100f));
        if (ConsumeAction("dropItem")) DropItem(Text("itemName", "Plank"), (int)Number("spawnAmount", 10f, 1f, 100f));
        if (ConsumeAction("spawnAnimal")) SpawnAnimal(Text("animalType", "Shark"));
        if (ConsumeAction("healPlayer") && player != null) Refill(player, new[] { "maxHealth", "MaxHealth" }, new[] { "health", "currentHealth", "Health" });
        if (ConsumeAction("clearNeeds") && player != null)
        {
            Refill(player, new[] { "maxHunger", "MaxHunger" }, new[] { "hunger", "currentHunger", "Hunger" });
            Refill(player, new[] { "maxThirst", "MaxThirst" }, new[] { "thirst", "currentThirst", "Thirst" });
            Refill(player, new[] { "maxOxygen", "MaxOxygen" }, new[] { "oxygen", "currentOxygen", "Oxygen" });
        }
    }

    public override void UnloadMod()
    {
        Physics.gravity = originalGravity;
        Time.timeScale = originalTimeScale;
        Time.fixedDeltaTime = originalFixedDelta;
        AudioListener.volume = originalVolume;
        Application.targetFrameRate = originalTargetFps;
        QualitySettings.vSyncCount = originalVSync;
        RenderSettings.fog = originalFog;
        RenderSettings.fogDensity = originalFogDensity;
        QualitySettings.shadowDistance = originalShadowDistance;
        QualitySettings.lodBias = originalLodBias;
        Physics.defaultSolverIterations = originalSolverIterations;
        Physics.sleepThreshold = originalSleepThreshold;
        Destroy(gameObject);
    }

    private void ReadSettings()
    {
        try
        {
            if (!File.Exists(settingsPath)) return;
            DateTime write = File.GetLastWriteTimeUtc(settingsPath);
            if (write == lastWrite) return;
            settings.Clear();
            foreach (string line in File.ReadAllLines(settingsPath))
            {
                int split = line.IndexOf('=');
                if (split > 0) settings[line.Substring(0, split).Trim()] = line.Substring(split + 1).Trim();
            }
            lastWrite = write;
        }
        catch { }
    }

    private float Number(string key, float fallback, float minimum, float maximum)
    {
        string text; float value;
        if (!settings.TryGetValue(key, out text) || !Single.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value)) value = fallback;
        return Mathf.Clamp(value, minimum, maximum);
    }

    private bool Toggle(string key, bool fallback)
    {
        string value;
        if (!settings.TryGetValue(key, out value)) return fallback;
        return value == "1" || value.Equals("true", StringComparison.OrdinalIgnoreCase) || value.Equals("on", StringComparison.OrdinalIgnoreCase);
    }

    private string Text(string key, string fallback)
    {
        string value;
        return settings.TryGetValue(key, out value) && !String.IsNullOrWhiteSpace(value) ? value : fallback;
    }

    private static void Refill(Network_Player player, string[] maximumNames, string[] currentNames)
    {
        foreach (Component component in player.GetComponents<Component>())
        {
            if (component == null) continue;
            object maximum = null;
            foreach (string name in maximumNames)
            {
                maximum = ReadMember(component, name);
                if (maximum != null) break;
            }
            if (maximum == null) continue;
            foreach (string name in currentNames) if (WriteMember(component, name, maximum)) return;
        }
    }

    private static object ReadMember(object target, string name)
    {
        Type type = target.GetType();
        FieldInfo field = type.GetField(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
        if (field != null) return field.GetValue(target);
        PropertyInfo property = type.GetProperty(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
        return property == null ? null : property.GetValue(target, null);
    }

    private static bool WriteMember(object target, string name, object value)
    {
        try
        {
            Type type = target.GetType();
            FieldInfo field = type.GetField(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (field != null) { field.SetValue(target, Convert.ChangeType(value, field.FieldType, CultureInfo.InvariantCulture)); return true; }
            PropertyInfo property = type.GetProperty(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (property != null && property.CanWrite) { property.SetValue(target, Convert.ChangeType(value, property.PropertyType, CultureInfo.InvariantCulture), null); return true; }
        }
        catch { }
        return false;
    }

    private bool ConsumeAction(string key)
    {
        string value;
        if (!settings.TryGetValue(key, out value) || String.IsNullOrWhiteSpace(value) || value == "0") return false;
        string handled;
        if (handledActions.TryGetValue(key, out handled) && handled == value) return false;
        handledActions[key] = value;
        return true;
    }

    private void Give(string itemName, int amount)
    {
        try
        {
            Network_Player player = RAPI.GetLocalPlayer();
            if (player != null) player.Inventory.AddItem(itemName, amount);
        }
        catch (Exception ex) { Debug.LogWarning("IsRic could not give " + itemName + ": " + ex.Message); }
    }

    private void DropItem(string itemName, int amount)
    {
        try
        {
            Network_Player player = RAPI.GetLocalPlayer();
            Item_Base item = ItemManager.GetItemByName(itemName);
            if (player == null || item == null) return;
            Helper.DropItem(new ItemInstance(item, amount, item.MaxUses), player.transform.position, player.CameraTransform.forward, player.transform.ParentedToRaft());
        }
        catch (Exception ex) { Debug.LogWarning("IsRic could not spawn item " + itemName + ": " + ex.Message); }
    }

    private void SpawnAnimal(string animalName)
    {
        try
        {
            if (!Raft_Network.IsHost) { Debug.LogWarning("IsRic animal spawning is host-only."); return; }
            AI_NetworkBehaviourType animal = (AI_NetworkBehaviourType)Enum.Parse(typeof(AI_NetworkBehaviourType), animalName, true);
            Network_Player player = RAPI.GetLocalPlayer();
            if (player == null) return;
            Vector3 spawnPosition = player.transform.position + player.transform.forward * 3f;
            if (animal == AI_NetworkBehaviourType.Boar || animal == AI_NetworkBehaviourType.Rat || animal == AI_NetworkBehaviourType.Bear ||
                animal == AI_NetworkBehaviourType.MamaBear || animal == AI_NetworkBehaviourType.Pig || animal == AI_NetworkBehaviourType.PolarBear ||
                animal == AI_NetworkBehaviourType.Hyena || animal == AI_NetworkBehaviourType.HyenaBoss)
            {
                NavMeshHit hit;
                if (!NavMesh.SamplePosition(spawnPosition, out hit, 8f, NavMesh.AllAreas))
                {
                    Debug.LogWarning("This Raft animal needs island ground nearby.");
                    return;
                }
                spawnPosition = hit.position;
            }
            AI_NetworkBehaviour spawned = ComponentManager<Network_Host_Entities>.Value.CreateAINetworkBehaviour(animal, spawnPosition);
            AI_NetworkBehaviour_Domestic domestic = spawned as AI_NetworkBehaviour_Domestic;
            if (domestic != null) domestic.QuickTameLate();
        }
        catch (Exception ex) { Debug.LogWarning("IsRic could not spawn Raft animal '" + animalName + "': " + ex.Message); }
    }
}
